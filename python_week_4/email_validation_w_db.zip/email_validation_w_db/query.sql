use email_validation;
select * from emails;